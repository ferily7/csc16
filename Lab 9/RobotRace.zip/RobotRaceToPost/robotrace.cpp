#include "robotrace.h"
#include <QDebug>

RobotRace::RobotRace(int N)
{


}

void RobotRace::resetRace()
{

}

void RobotRace::update()
{

}

bool RobotRace::hasWinner(int & winner)
{


}

int RobotRace::getRobotPos(int i)
{

}

int RobotRace::getNumRobots()
{

}

int RobotRace::getLeader()
{
    int leader = 0;
    for(int i = 0; i < numRobots; i ++){
        if ( robots[i]->getPosition() > robots[leader]->getPosition()){
            leader = i;
        }
    }
    return leader;
}
