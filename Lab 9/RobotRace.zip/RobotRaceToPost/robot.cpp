#include "robot.h"

Robot::Robot()
{

}

void Robot::resetRobot()
{

}

void Robot::update()
{  //Use the qrand() function instead of rand() in here.


}

int Robot::getPosition()
{

}
