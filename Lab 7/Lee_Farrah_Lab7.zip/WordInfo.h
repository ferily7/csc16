//
//  WordInfo.h
//  analyzer

#include <string>
#include <vector>
#include <iostream>
using namespace std;

struct WordInfo{
    string word;
    vector<int> lines;
};

