#include "stack.h"

Stack::Stack()
{
    //Complete this function; it's identical to the LinkedList constructor you saw in class
    //Steps:
    //1. Set head to point to no Node
    //2. Set numNodes to zero.
}

/**
  The push function should insert the given item at the front of the list.
 * @brief Stack::push
 * @param item
 */
void Stack::push(double item)
{
    //Complete this function.
    //Steps:
    //1. Create a temp pointer
    //2. Point temp at a new Node object with 'item' in it.
    //3. Create a link from the new Node to the current head Node of the list
    //4. Make head point to the new Node
    //5. Increment numNodes
}

double Stack::pop()
{
    //Complete this function
    //Steps:
    //1. Create a temp pointer
    //2. Point temp at the head Node
    //3. Copy the data value from the head Node into a variable called "saved"
    //4. Move the head pointer forward.
    //5. Delete the temp Node
    //6. Decrement numNodes
    //7. Return "saved"
}

int Stack::size()
{
    return numNodes;
}
